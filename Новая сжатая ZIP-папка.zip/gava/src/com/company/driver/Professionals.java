package com.company.driver;

public class Professionals {
    public String name;
    public String exp;

    public Professionals(String name, String exp) {
        this.name = name;
        this.exp = exp;
    }


}
